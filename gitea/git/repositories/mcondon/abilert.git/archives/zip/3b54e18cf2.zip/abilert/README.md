# Abilert

Abilert is a combined mobile device, embedded device and web server project to build a scalable, personalizable emergency alert system.

# Intentions

In broad strokes, we will develop a server which which can be configured to alert a list of contacts under specified circumstances, as well as a set of mobile and embedded devices to interact with that server. 

Intended use-cases are as a physical "dead man's switch" to alert when PCAs/DSWs fail to arrive for shift with a secondary function as an active alert device. PCA schedules should be configurable through Google Calendar. Emergency contact lists, contents, and preferences will be configurable through a web interface, with stats reviewable through an attached dashboard. 

Enrollment of new devices for an existing account will be available, but precise details have not yet been decided. 

This project will be both open source and open design: I will publish my development plan along with the code. 

# Usage

# Installation

# Development Focus

# Known Issues

# TODO
 
# contact

This project is managed by Michael Condon.
If you have questions, would like to use the project in your own work, or would like to help contribute, please contact michael.r.condon@gmail.com